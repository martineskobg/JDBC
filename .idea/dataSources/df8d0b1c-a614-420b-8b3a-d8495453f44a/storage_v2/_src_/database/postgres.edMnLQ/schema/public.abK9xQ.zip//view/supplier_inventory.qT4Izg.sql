create view supplier_inventory (supplier_id, name, phone, quantity, price_with_vat, price_without_vat, warehouse) as
SELECT suppliers.supplier_id,
       suppliers.name,
       suppliers.phone,
       pi.quantity,
       pi.price_with_vat,
       pi.price_without_vat,
       pi.warehouse
FROM suppliers
         JOIN products_inventory pi ON pi.supplier_id = suppliers.supplier_id
WHERE pi.quantity > 0
ORDER BY suppliers.name;

alter table supplier_inventory
    owner to postgres;

